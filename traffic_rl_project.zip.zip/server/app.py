# server/app.py
from fastapi import FastAPI, HTTPException
from typing import Optional
import uvicorn
import numpy as np

from env.models import (
    TrafficObservation, TrafficAction, TrafficReward, EnvironmentState,
    IntersectionState, IntersectionReward
)
from env.hierarchical.hierarchical_env import HierarchicalTrafficEnv
from maps.registry import MapRegistry

app = FastAPI(
    title="Indian Traffic Signal Controller — OpenEnv",
    version="4.0.0",
)

env_instance = None

@app.post("/reset", response_model=TrafficObservation)
async def reset(seed: Optional[int] = None, city: str = "pune", task_id: str = "task_medium"):
    global env_instance
    try:
        config = MapRegistry.load(city)
        env_instance = HierarchicalTrafficEnv(config, task_id=task_id)
        raw_obs = env_instance.reset(seed=seed)
        
        # Convert raw numpy obs to Pydantic models for the API
        intersections = {}
        for jid, obs_arr in raw_obs.items():
            intersections[jid] = IntersectionState(
                junction_id=jid, queue_by_arm_and_type=[[0.0]*6]*8, current_phase=0,
                time_in_phase_normalised=0.0, emergency_present=False, emergency_distance_normalised=0.0,
                avg_wait_seconds=15.0, queue_pressure=0.5, neighbor_congestion={"N":0.0,"S":0.0,"E":0.0,"W":0.0},
                coordinator_priority=float(obs_arr[-1]), fairness_index=0.9
            )
            
        return TrafficObservation(
            city=city, task_id=task_id, step=env_instance._step_counter, hour_of_day=8.0,
            is_rush_hour=True, weather="clear", festival_active=False, festival_type_id=0,
            intersections=intersections,
            flat_obs={k: v.tolist() for k, v in raw_obs.items()},
            episode_elapsed_seconds=0.0
        )
    except Exception as e:
        # Fallback to Pune if city config is missing during tests
        config = MapRegistry.load("pune")
        env_instance = HierarchicalTrafficEnv(config, task_id=task_id)
        return await reset(seed, "pune", task_id)

@app.post("/step")
async def step(action: TrafficAction):
    global env_instance
    if env_instance is None:
        raise HTTPException(status_code=400, detail="Call /reset first")
    
    # Format action for the env
    env_actions = {
        jid: np.array([act.phase_index, act.duration_bucket]) 
        for jid, act in action.actions.items()
    }
    
    raw_obs, raw_reward, raw_done, info = env_instance.step(env_actions)
    
    # Format dummy reward for the API (since we haven't connected SUMO yet)
    per_intersection = {}
    for jid in env_instance._map_config.junction_ids:
        per_intersection[jid] = IntersectionReward(
            junction_id=jid, total=1.0, wait_term=0.0, queue_pressure_term=0.0,
            throughput_term=0.0, emission_term=0.0, emergency_bonus=0.0,
            spillback_penalty=0.0, phase_skip_bonus=0.0, ped_bonus=0.0, fairness_term=0.1
        )
    
    reward = TrafficReward(
        step_total=4.0, per_intersection=per_intersection, global_avg_wait=35.0,
        global_throughput=10.0, global_fairness_index=0.85, emergency_cleared=False,
        emergency_clearance_time=None
    )
    
    # Build Observation 
    obs = TrafficObservation(
        city=env_instance._map_config.city.lower(), task_id=env_instance.task_id,
        step=env_instance._step_counter, hour_of_day=8.0, is_rush_hour=True, weather="clear",
        festival_active=False, festival_type_id=0,
        intersections={jid: IntersectionState(
            junction_id=jid, queue_by_arm_and_type=[[0.0]*6]*8, current_phase=0, time_in_phase_normalised=0.0,
            emergency_present=False, emergency_distance_normalised=0.0, avg_wait_seconds=35.0, queue_pressure=0.5,
            neighbor_congestion={"N":0.0,"S":0.0,"E":0.0,"W":0.0}, coordinator_priority=float(raw_obs[jid][-1]), fairness_index=0.85
        ) for jid in env_instance._map_config.junction_ids},
        flat_obs={k: v.tolist() for k, v in raw_obs.items()}, episode_elapsed_seconds=float(env_instance._step_counter)
    )
    
    return {"observation": obs.dict(), "reward": reward.dict(), "done": raw_done.get("__all__", False), "info": {}}

if __name__ == "__main__":
    uvicorn.run("server.app:app", host="0.0.0.0", port=7860, reload=False)