#!/usr/bin/env python3
"""
inference.py — Indian Traffic Signal Controller Baseline Inference
==================================================================
MANDATORY environment variables:
    API_BASE_URL   LLM endpoint
    MODEL_NAME     Model identifier
    HF_TOKEN       HuggingFace / API key
"""

import os
import json
import time
import textwrap
import sys
from typing import Dict

import requests
from openai import OpenAI

API_BASE_URL = os.getenv("API_BASE_URL", "https://router.huggingface.co/v1")
API_KEY      = os.getenv("HF_TOKEN") or os.getenv("API_KEY", "dummy_key")
MODEL_NAME   = os.getenv("MODEL_NAME", "meta-llama/Llama-3.1-8B-Instruct")
ENV_BASE_URL = os.getenv("ENV_BASE_URL", "http://localhost:7860")

# Set low for rapid testing
MAX_STEPS   = 10     
EPISODES    = 1       
TEMPERATURE = 0.1
MAX_TOKENS  = 200

TASKS = [
    {"task_id": "task_easy",   "city": "pune",      "difficulty": "easy"},
    {"task_id": "task_medium", "city": "pune",      "difficulty": "medium"},
]

SYSTEM_PROMPT = textwrap.dedent("""
    You control Indian traffic signals. Coordinate 4 intersections.
    Reply ONLY with valid JSON.
    {"actions": {"junction_id": {"phase_index": 0, "duration_bucket": 1}, ...}}
""").strip()

def log_start(task_id: str, city: str, episode: int, seed: int):
    print(f"[START] task={task_id} city={city} episode={episode} seed={seed} model={MODEL_NAME}", flush=True)

def log_step(step: int, reward: float, done: bool, avg_wait: float, fairness: float):
    print(f"[STEP] step={step} reward={reward:.4f} done={str(done).lower()} avg_wait={avg_wait:.2f} fairness={fairness:.4f}", flush=True)

def log_end(task_id: str, episode: int, score: float, steps: int):
    print(f"[END] task={task_id} episode={episode} score={score:.4f} steps={steps}", flush=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from env.graders.task_easy_grader   import ReduceWaitGrader
from env.graders.task_medium_grader import CooperativeFlowGrader
from env.models import TrafficReward  

GRADER_MAP = {"task_easy": ReduceWaitGrader, "task_medium": CooperativeFlowGrader}

def call_reset(city: str, task_id: str, seed: int) -> dict:
    resp = requests.post(f"{ENV_BASE_URL}/reset", params={"city": city, "task_id": task_id, "seed": seed}, timeout=30)
    resp.raise_for_status()
    return resp.json()

def call_step(actions: dict) -> dict:
    resp = requests.post(f"{ENV_BASE_URL}/step", json={"actions": actions}, timeout=15)
    resp.raise_for_status()
    return resp.json()

def parse_actions(response_text: str, junction_ids: list) -> dict:
    default = {jid: {"phase_index": 0, "duration_bucket": 1} for jid in junction_ids}
    return default # Force default for dry-run to avoid LLM auth errors

def run_episode(client: OpenAI, task_id: str, city: str, seed: int) -> float:
    grader = GRADER_MAP[task_id]()
    obs = call_reset(city, task_id, seed=seed)
    junction_ids = list(obs.get("intersections", {}).keys())

    log_start(task_id, city, episode=seed // 42 + 1, seed=seed)

    for step in range(1, MAX_STEPS + 1):
        raw_actions = parse_actions("", junction_ids)
        payload_actions = {jid: {"junction_id": jid, **act} for jid, act in raw_actions.items()}
        
        step_result = call_step(payload_actions)
        reward = step_result["reward"]
        done   = step_result["done"]

        avg_wait = reward.get("global_avg_wait", 0.0)
        fairness = reward.get("global_fairness_index", 0.0)
        step_r   = reward.get("step_total", 0.0)

        log_step(step, step_r, done, avg_wait, fairness)
        
        grader.on_step(TrafficReward(**reward), step)

        if done: break

    score = grader.score()
    log_end(task_id, episode=seed // 42 + 1, score=score, steps=step)
    return score

def main():
    print("=" * 60, flush=True)
    print(f"Indian Traffic Controller v4 — Baseline Inference", flush=True)
    print("=" * 60, flush=True)

    client = OpenAI(base_url=API_BASE_URL, api_key=API_KEY)
    all_scores = {}

    for task_cfg in TASKS:
        task_id, city = task_cfg["task_id"], task_cfg["city"]
        print(f"\nTASK: {task_id} | City: {city}")
        
        score = run_episode(client, task_id, city, seed=0)
        all_scores[task_id] = round(score, 4)

    print("\nFINAL BASELINE SCORES")
    for task_id, score in all_scores.items():
        print(f"  {task_id:22s}  {score:.4f}")

    with open("baseline_scores.json", "w") as f:
        json.dump({"scores": all_scores, "model": MODEL_NAME}, f, indent=2)

if __name__ == "__main__":
    main()